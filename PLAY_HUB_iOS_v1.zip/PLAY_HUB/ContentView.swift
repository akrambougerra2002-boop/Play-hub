import SwiftUI

struct Product: Identifiable, Codable {
    let id = UUID()
    var name: String
    var price: Int
    var stock: Int
}
struct Operation: Identifiable, Codable {
    let id = UUID()
    var title: String
    var amount: Int
    var date: Date
}

final class Store: ObservableObject {
    @Published var operations: [Operation] = [] { didSet { save() } }
    @Published var products: [Product] = [
        Product(name:"Canet",price:1000,stock:0), Product(name:"Izem plastique",price:900,stock:0),
        Product(name:"Choueps",price:800,stock:0), Product(name:"Coca",price:700,stock:0),
        Product(name:"Jus",price:700,stock:0), Product(name:"Daili",price:300,stock:0),
        Product(name:"Joy",price:150,stock:0), Product(name:"Candi choco kbir",price:600,stock:0),
        Product(name:"Candia choco sghir",price:400,stock:0), Product(name:"Jus hlib",price:800,stock:0),
        Product(name:"Madlen",price:600,stock:0), Product(name:"Gatou",price:400,stock:0),
        Product(name:"Dolce sol",price:500,stock:0), Product(name:"Dolce",price:600,stock:0)
    ] { didSet { save() } }

    init() { load() }
    var today: [Operation] { operations.filter { Calendar.current.isDateInToday($0.date) } }
    var total: Int { today.reduce(0){$0+$1.amount} }
    private func save() {
        let d=UserDefaults.standard
        if let x=try? JSONEncoder().encode(operations){d.set(x,forKey:"ops")}
        if let x=try? JSONEncoder().encode(products){d.set(x,forKey:"products")}
    }
    private func load() {
        let d=UserDefaults.standard
        if let x=d.data(forKey:"ops"), let v=try? JSONDecoder().decode([Operation].self,from:x){operations=v}
        if let x=d.data(forKey:"products"), let v=try? JSONDecoder().decode([Product].self,from:x){products=v}
    }
    func add(_ title:String,_ amount:Int) { operations.append(Operation(title:title,amount:amount,date:Date())) }
}

struct ContentView: View {
    @StateObject private var store=Store()
    @State private var tab=0
    var body: some View {
        TabView(selection:$tab) {
            Home(store:store).tabItem{Label("الرئيسية",systemImage:"house.fill")}.tag(0)
            Games(store:store).tabItem{Label("الألعاب",systemImage:"gamecontroller.fill")}.tag(1)
            Sales(store:store).tabItem{Label("المبيعات",systemImage:"cup.and.saucer.fill")}.tag(2)
            Stock(store:store).tabItem{Label("المخزون",systemImage:"shippingbox.fill")}.tag(3)
        }
        .tint(.red)
        .environment(\.layoutDirection,.rightToLeft)
    }
}

struct Home: View {
    @ObservedObject var store:Store
    var body: some View {
        NavigationStack {
            ScrollView { VStack(spacing:14) {
                Text("PLAY HUB 🎮").font(.largeTitle.bold()).frame(maxWidth:.infinity,alignment:.leading)
                Card(title:"مداخيل اليوم",value:"\(store.total) دج",icon:"banknote.fill")
                let games=store.today.filter{$0.title.hasPrefix("🎮")}.reduce(0){$0+$1.amount}
                let sales=store.today.filter{$0.title.hasPrefix("🥤")}.reduce(0){$0+$1.amount}
                HStack { SmallCard(t:"الألعاب",v:"\(games) دج"); SmallCard(t:"المبيعات",v:"\(sales) دج") }
                Text("عدد العمليات: \(store.today.count)").foregroundStyle(.secondary)
            }.padding() }.navigationTitle("الرئيسية")
        }
    }
}
struct Card: View { let title:String; let value:String; let icon:String
    var body:some View{VStack(alignment:.leading){Image(systemName:icon).font(.title2);Text(title).foregroundStyle(.secondary);Text(value).font(.title.bold())}.frame(maxWidth:.infinity,alignment:.leading).padding().background(.thinMaterial).clipShape(RoundedRectangle(cornerRadius:18))}
}
struct SmallCard:View{let t:String;let v:String;var body:some View{VStack{Text(t).foregroundStyle(.secondary);Text(v).font(.headline)}.frame(maxWidth:.infinity).padding().background(.thinMaterial).clipShape(RoundedRectangle(cornerRadius:15))}}

struct Games: View {
    @ObservedObject var store:Store
    var body:some View{
        NavigationStack{ScrollView{VStack(spacing:12){
            Text("PS4 — مباراة ×2").font(.headline).frame(maxWidth:.infinity,alignment:.leading)
            GameButton(title:"PS4 Slim ×2",price:500){store.add("🎮 PS4 Slim ×2",500)}
            GameButton(title:"PS4 Pro ×2",price:500){store.add("🎮 PS4 Pro ×2",500)}
            GameButton(title:"PS4 Fat ×2",price:500){store.add("🎮 PS4 Fat ×2",500)}
            GameButton(title:"PS4 ×4",price:1000){store.add("🎮 PS4 ×4",1000)}
            Divider().padding(.vertical,4)
            GameButton(title:"🎱 Billiard — مباراة",price:700){store.add("🎮 Billiard",700)}
            Text("Xbox — Blur").font(.headline).frame(maxWidth:.infinity,alignment:.leading)
            GameButton(title:"Blur ×2",price:300){store.add("🎮 Xbox Blur ×2",300)}
            GameButton(title:"Blur ×3",price:400){store.add("🎮 Xbox Blur ×3",400)}
            GameButton(title:"Blur ×4",price:500){store.add("🎮 Xbox Blur ×4",500)}
        }.padding()}.navigationTitle("الألعاب")}
    }
}
struct GameButton:View{let title:String;let price:Int;let action:()->Void
    var body:some View{Button(action:action){HStack{Text(title);Spacer();Text("\(price) دج").bold()}.padding().background(Color.red.opacity(0.15)).clipShape(RoundedRectangle(cornerRadius:14))}.buttonStyle(.plain)}
}

struct Sales:View{
    @ObservedObject var store:Store
    var body:some View{NavigationStack{List{ForEach(store.products.indices,id:\.self){i in
        Button{store.add("🥤 \(store.products[i].name)",store.products[i].price); if store.products[i].stock>0{store.products[i].stock-=1}}label:{
            HStack{Text(store.products[i].name);Spacer();Text("\(store.products[i].price) دج").bold()}
        }.foregroundStyle(.primary)
    }}.navigationTitle("المشروبات والحلويات")}}
}
struct Stock:View{
    @ObservedObject var store:Store
    var body:some View{NavigationStack{List{ForEach(store.products.indices,id:\.self){i in
        HStack{Text(store.products[i].name);Spacer();Stepper("\(store.products[i].stock)",value:$store.products[i].stock,in:0...999)}
    }}.navigationTitle("المخزون")}}
}
