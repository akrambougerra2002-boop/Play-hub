import SwiftUI

@main
struct PLAY_HUBApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
