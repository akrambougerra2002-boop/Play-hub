# PLAY HUB — iPhone v1

مشروع SwiftUI للـ iPhone مبني على الأسعار والمنتجات التي حددها صاحب PLAY HUB.

## الأسعار
PS4: ×2 = 500 دج، ×4 = 1000 دج.
Billiard = 700 دج.
Xbox Blur: ×2 = 300، ×3 = 400، ×4 = 500 دج.

## التشغيل
افتح المجلد في Xcode على Mac، أنشئ iOS App باسم PLAY HUB، ثم استبدل ملفات Swift بالملفات الموجودة هنا.
البيانات تحفظ محلياً على iPhone عبر UserDefaults.
